﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BiblioClasse
{
    public class Rapport
    {
        #region variable
        private int idRap;
        private DateTime date;
        private string modif;
        private string bilan;
        private string idVisiteur;
        private int idMedecin;
        #endregion
    }
}
