﻿using BiblioClasse;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainWindows
{
    public partial class frmMedecin : Form
    {
        public static List<Medecin> medic = new List<Medecin>();
        public frmMedecin()
        {
            InitializeComponent();
            insertion();
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            PopAjoutsMedecin fp = new PopAjoutsMedecin();
            fp.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        public void insertion()
        {
            medic.Clear();
            medic.Add(new Medecin(0657494675, 58, 1, "Leduque","Lèo","58 rue bure"));
            medic.Add(new Medecin(0585824670, 58, 2, "Leue", "pagr", "47 rue reat"));
            //PopAjoutsMedecin.craftmedic;

            for (int i = 0; i < (medic.Count); i++)
            {
                dataGridView1.Rows.Add(medic[i].Nom, medic[i].Prenom, medic[i].Adresse, medic[i].Tel, medic[i].Departement);
            }
        }
         
    }
}
